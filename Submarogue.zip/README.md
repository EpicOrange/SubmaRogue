# SubmaRogue
open main.html to play

## Controls:
  movement: arrowkeys, numpad
  
  pick up item: ,
  
  ascend stairs: <
  
  descend stairs: >
  
